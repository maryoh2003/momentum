const form = document.querySelector(".js-greetingForm");
input = form.querySelector("input");
greeting = document.querySelector(".js-greetings");

const user_list = "currentUser";
console.log(user_list);
showing = "showing";

function saveName(text) {
  localStorage.setItem(user_list, text);
}

function submit(event) {
  event.preventDefault();
  const currentValue = input.value;
  paintGreeting(currentValue);
  saveName(currentValue);
}

function requestName() {
  form.classList.add(showing);
  form.addEventListener("submit", submit);
}

function paintGreeting(text) {
  form.classList.remove(showing);
  greeting.classList.add(showing);
  const date = new Date();
  const hours = date.getHours();

  if (5 <= hours && hours < 12) {
    greeting.innerText = `Good morning, ${text}`;
  } else if (12 <= hours && hours < 17) {
    greeting.innerText = `Good afternoon, ${text}`;
  } else {
    greeting.innerText = `Good evening, ${text}`;
  }
}

function loadName() {
  const currentUser = localStorage.getItem(user_list);
  if (currentUser === null) {
    requestName();
  } else {
    paintGreeting(currentUser);
  }
}

function init() {
  loadName();
}

init();
