const clockContainer = document.querySelector(".js-clock");
let clockTitle = clockContainer.querySelector("h1");
let clockTitle2 = clockContainer.querySelector("p");
let clockBefore = document.querySelector("h2");

function getTime() {
  const date = new Date();
  const minutes = date.getMinutes();
  const hours = date.getHours();
  const seconds = date.getSeconds();
  clockTitle.innerText = `${hours < 10 ? `0${hours}` : hours}:${
    minutes < 10 ? `0${minutes}` : minutes
  }:`;
  clockTitle2.innerText = `${seconds < 10 ? `0${seconds}` : seconds}`;

  // let before_second = seconds - 1;
  // if (before_second < 0) {
  //   before_second = 59;
  // }
  // clockBefore.innerText = `${
  //   before_second < 10 ? `0${before_second}` : before_second
  // }`;
}

function init() {
  getTime();
  setInterval(getTime, 1000);
}

init();
