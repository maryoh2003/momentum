const toDoForm = document.querySelector(".js-todoForm"),
  toDoInput = toDoForm.querySelector("input"),
  toDoList = document.querySelector(".js-toDoList");

const todo_list = "toDos";

let toDos = [];

function loadtodo() {
  const loaded = localStorage.getItem(todo_list);
  if (loaded !== null) {
    const parsedToDos = JSON.parse(loaded);
    parsedToDos.forEach(todo => {
      console.log(todo.text);
      paintToDo(todo.text);
    });
  }
}

function deletetodo(event) {
  const btn = event.target;
  const li = btn.parentNode;
  toDoList.removeChild(li);
  const cleanToDos = toDos.filter(toDo => {
    return toDo.id !== parseInt(li.id);
  });
  toDos = cleanToDos;
  saveToDos();
}

function saveToDos() {
  localStorage.setItem(todo_list, JSON.stringify(toDos));
}

function paintToDo(text) {
  const li = document.createElement("li");
  const span = document.createElement("span");
  const del = document.createElement("i");
  const newId = toDos.length + 1;

  del.className = "btn fas fa-times";
  del.addEventListener("click", deletetodo);

  span.innerText = text;
  li.appendChild(del);
  li.appendChild(span);

  li.id = newId;
  toDoList.appendChild(li);
  console.log(toDos.length);

  if (toDos.length > 7) {
    document.getElementById("todo").disabled = true;
  }
  const toDoObj = {
    text: text,
    id: newId
  };
  toDos.push(toDoObj);
  saveToDos();
}

function submit(event) {
  event.preventDefault();
  const currentValue = toDoInput.value;
  paintToDo(currentValue);
  toDoInput.value = "";
}

function init() {
  loadtodo();
  toDoForm.addEventListener("submit", submit);
}

init();
