const body = document.querySelector("body");

const img_num = 9;

function paintImage(imgNumber) {
  const image = new Image();
  image.src = `images/${imgNumber + 1}.jpg`;
  image.classList.add("bgImage");
  body.appendChild(image);
}

function getRan() {
  const number = Math.floor(Math.random() * img_num);
  return number;
}

function init() {
  const randomNumber = getRan();
  paintImage(randomNumber);
}

init();
