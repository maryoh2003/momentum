const TimeContainer = document.querySelector(".countdown");
let MinuteContainer = TimeContainer.querySelector("h5");

function getMinutes() {
  const date = new Date();
  const minutes = date.getMinutes();
  const hours = date.getHours();
  const fullminutes = 1440;
  let minusminutes = minutes + hours * 60;
  let totalminutes = fullminutes - minusminutes;
  MinuteContainer.innerText = `${totalminutes}`;
  console.log(MinuteContainer.innerText);
}

function init() {
  getMinutes();
  setInterval(getMinutes, 1000);
}
init();
